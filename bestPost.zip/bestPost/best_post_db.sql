-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Generation Time: Feb 05, 2024 at 04:24 AM
-- Server version: 10.4.32-MariaDB
-- PHP Version: 8.2.12

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Database: `best_post_db`
--

-- --------------------------------------------------------

--
-- Table structure for table `post`
--

CREATE TABLE `post` (
  `id` int(10) NOT NULL,
  `created_date` datetime NOT NULL,
  `user_id` int(10) NOT NULL,
  `title` varchar(255) NOT NULL,
  `image` varchar(255) NOT NULL,
  `text` text NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `post`
--

INSERT INTO `post` (`id`, `created_date`, `user_id`, `title`, `image`, `text`) VALUES
(2, '2024-02-05 08:42:29', 1, 'Test', '8208.jpg', 'Test'),
(3, '2024-02-05 08:43:49', 5, 'Test 001', '3460.jpg', 'rrr'),
(4, '2024-02-05 08:52:43', 8, 'My post', '2623.jpg', 'addas');

-- --------------------------------------------------------

--
-- Table structure for table `user`
--

CREATE TABLE `user` (
  `id` int(10) NOT NULL,
  `created_date` datetime NOT NULL,
  `role` varchar(200) NOT NULL,
  `fullname` varchar(255) NOT NULL,
  `username` varchar(200) NOT NULL,
  `password` varchar(255) NOT NULL,
  `read_access` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=access not allowed, 1=access allowed',
  `update_access` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=access not allowed, 1=access allowed',
  `delete_access` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=access not allowed, 1=access allowed',
  `admin_access` enum('0','1') NOT NULL DEFAULT '0' COMMENT '0=access not allowed, 1=access allowed'
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Dumping data for table `user`
--

INSERT INTO `user` (`id`, `created_date`, `role`, `fullname`, `username`, `password`, `read_access`, `update_access`, `delete_access`, `admin_access`) VALUES
(1, '2024-01-07 18:07:43', 'superadmin', 'Super Admin', 'superadmin', 'c42aad84a73411b78de30dc2138333216aa71d5887dbe556fbfd43100e9d99d6bd452a6ed57f1b440b3477b3191dd7eb4e0522b44eeafeca4fb059d1cea79ace536280649f16d3041e837b40824e514d77e013a5d8', '1', '1', '1', '1'),
(5, '2024-02-05 01:18:29', 'admin', 'Admin User Default', 'admin', '1af9678686c045da65cd670c95b6eaca28c12b88099bc66576915ea9589034dc9c96553c2b81d074084eaa9ac589bfa4814499f0eeac860bd750010dbcc6d7fd0fc1fa6d9ee4c3e795e783e727932abe7e0ef0402b', '0', '0', '0', '0'),
(6, '2024-02-05 08:44:58', 'admin', 'Admin User Read', 'adminR', 'e2b7e264110aee925683b9e441f51f0d71a43c07fc64879c3f0ff98c71f43850b2d3916fe73370e2ebcbf1dae3dbfcdf99ecbd944aa674828ecc4440840959efae16638a47ba597ee34749966a8d25ad62753463ed', '1', '0', '0', '1'),
(7, '2024-02-05 08:45:24', 'admin', 'Admin User Update', 'adminU', '4467013287f48c7c7b471cef5c2a5df666c1764f5883b2000d6e5dae4c0ff33fd9dbd2485975a84540e2a9dc6dd52058d1647f93ec2d5737d543acd645b30d47cc505a356186c4e72250fcf16975e5d739078a696e', '0', '1', '0', '1'),
(8, '2024-02-05 08:45:57', 'admin', 'Admin User Delete', 'adminD', 'df61b3296b2ff12c8829b4e0be14d590cf73d7c70fbdc84f03bae3425374883dc7db360eeb9a7d866f40d9663dfc02fd98b56adefc1fecb0be0f0cf88de24b66f26f1e7519752d6531663bf75d2073d0556c8209df', '0', '0', '1', '1');

--
-- Indexes for dumped tables
--

--
-- Indexes for table `post`
--
ALTER TABLE `post`
  ADD PRIMARY KEY (`id`),
  ADD KEY `post_user_id` (`user_id`);

--
-- Indexes for table `user`
--
ALTER TABLE `user`
  ADD PRIMARY KEY (`id`);

--
-- AUTO_INCREMENT for dumped tables
--

--
-- AUTO_INCREMENT for table `post`
--
ALTER TABLE `post`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=5;

--
-- AUTO_INCREMENT for table `user`
--
ALTER TABLE `user`
  MODIFY `id` int(10) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=9;

--
-- Constraints for dumped tables
--

--
-- Constraints for table `post`
--
ALTER TABLE `post`
  ADD CONSTRAINT `post_user_id` FOREIGN KEY (`user_id`) REFERENCES `user` (`id`);
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;
