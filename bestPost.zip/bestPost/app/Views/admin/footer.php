
            <!-- Footer Start -->
            <div class="container-fluid pt-4 px-4 fixed-bottom bottom-0 start-0 end-0" style="z-index: 1;">
                <div class="bg-secondary rounded-top p-4">
                    <div class="text-center">
                        &copy; <a href="<?php echo base_url(); ?>">Best Post</a>, All Right Reserved. 
                    </div>
                </div>
            </div>
            <!-- Footer End -->
        </div>
        <!-- Content End -->


        <!-- Back to Top -->
        <a href="#" class="btn btn-lg btn-primary btn-lg-square back-to-top"><i class="bi bi-arrow-up"></i></a>
    </div>

    <!-- JavaScript Libraries -->
    <script src="<?php echo base_url(); ?>/assets/code.jquery.com/jquery-3.4.1.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/cdn.jsdelivr.net/npm/bootstrap%405.0.0/dist/js/bootstrap.bundle.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/lib/chart/chart.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/lib/easing/easing.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/lib/waypoints/waypoints.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/lib/owlcarousel/owl.carousel.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/lib/tempusdominus/js/moment.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/lib/tempusdominus/js/moment-timezone.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/lib/tempusdominus/js/tempusdominus-bootstrap-4.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/jquery.validate.min.js"></script>
    <script src="<?php echo base_url(); ?>/assets/js/cute-alert.js"></script>

    <!-- Template Javascript -->
    <script src="<?php echo base_url(); ?>/assets/js/main.js"></script>
  </body>
</html>