<?php echo view('admin/header'); ?>

    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded p-4">
            <h3><?php if ($userData){ echo 'Add User'; }else{ echo 'Edit User'; } ?> </h3>
        </div>
        <div class="bg-secondary rounded p-4 mt-3 mt-5">
            <form id="userForm" method="POST">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="fullname" name="fullname" placeholder="Basilah Khan" value="<?php if ($userData){ echo $userData['fullname']; } ?>">
                            <label for="fullname">Full Name</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="username" name="username" placeholder="Basilah" value="<?php if ($userData){ echo $userData['username']; } ?>">
                            <label for="username">Username</label>
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-6">
                        <div class="row ms-1 mx-1">
                            <div class="col-10 form-floating mb-4 p-0">
                                <input type="password" class="form-control" id="password" name="password" placeholder="Password" value="<?php if ($userData){ echo $userData['password']; } ?>">
                                <label for="password">Password</label>
                            </div>
                            <div class="col-2 mb-4 p-0">
                                <button type="button" class="btn btn-warning py-3 w-100 mb-4" onclick="togglePassword();">
                                    <i class="fa fa-eye" id="eye"></i>
                                </button>
                            </div>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-floating mb-3">
                            <h6 class="mb-4">Access</h6>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="read" id="read" <?php if ($userData){ if($userData['read_access'] == '1'){ echo 'checked'; } } ?>>
                                <label class="form-check-label" for="read">
                                    Read Access
                                </label>
                                <input type="hidden" name="read_access" id="read_access" value="<?php if ($userData){ echo $userData['read_access']; }else{ echo '0'; } ?>">
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="update" id="update" <?php if ($userData){ if($userData['update_access'] == '1'){ echo 'checked'; } } ?>>
                                <label class="form-check-label" for="update">
                                    Update Access
                                </label>
                                <input type="hidden" name="update_access" id="update_access" value="<?php if ($userData){ echo $userData['update_access']; }else{ echo '0'; } ?>">
                            </div>
                            <div class="form-check">
                                <input class="form-check-input" type="checkbox" name="delete" id="delete" <?php if ($userData){ if($userData['delete_access'] == '1'){ echo 'checked'; } } ?>>
                                <label class="form-check-label" for="delete">
                                    Delete Access
                                </label>
                                <input type="hidden" name="delete_access" id="delete_access" value="<?php if ($userData){ echo $userData['delete_access']; }else{ echo '0'; } ?>">
                                <input type="hidden" name="id" value="<?php if ($userData){ echo $userData['id']; } ?>">
                            </div>
                        </div>
                    </div>
                </div>
                <div class="row mt-2">
                    <div class="col-sm-3">
                    </div>
                    <div class="col-sm-3">
                        <button type="reset" class="btn btn-warning w-100">Rest</button>
                    </div>
                    <div class="col-sm-3">
                        <button type="submit" class="btn btn-primary w-100 formbtn">Save</button>
                    </div>
                    <div class="col-sm-3">
                    </div>
                </div>
            </form>
        </div>
    </div> 

<?php echo view('admin/footer'); ?>

<script type="text/javascript">    
    function togglePassword() {
        $("#eye").toggleClass("fa-eye fa-eye-slash");
        input = $("#password");
        if (input.attr("type") == "password") {
          input.attr("type", "text");
        } else {
          input.attr("type", "password");
        }
    }

    $("#userForm").validate({
        rules: {
          fullname: "required",
          username: "required",
          password: "required"
        },
        messages: {
          fullname: "Please Enter Fullname. This field is required.",
          username: "Please Enter Username. This field is required.",
          password: "Please Enter Password. This field is required."
        },
        errorPlacement: function (error, element) {
          error.insertBefore(element.parent());
        },
        submitHandler: function () {
            $('.formbtn').prop('disabled', true);

            read = $('#read').is(':checked');
            if (read) { $('#read_access').val(1); }else{ $('#read_access').val(0); }
            update = $('#update').is(':checked');
            if (update) { $('#update_access').val(1); }else{ $('#update_access').val(0); }
            deleteAccess = $('#delete').is(':checked');
            if (deleteAccess) { $('#delete_access').val(1); }else{ $('#delete_access').val(0); }

            $.ajax({
                url: "<?php if ($userData){ echo base_url() .'/api/ajaxEditUser'; }else{ echo base_url().'/api/ajaxAddUser';} ?>",
                type: 'post',
                data: $('#userForm').serialize(),
                dataType: 'json',
                success: function (data) {
                    cuteToast({
                        title: data.title,
                        type: data.status,
                        message: data.message,
                        timer: 1500
                    });

                    if (data.status == 'success') {
                        setTimeout(function () {
                            window.location.href = "<?php echo base_url() .'/user/list'; ?>";
                        },1600);
                    }
                    
                    $('.formbtn').prop('disabled', false);
                },            
                error: function (data) {
                    window.location.reload();
                    $('.formbtn').prop('disabled', false);
                }
            });
            return false;
        }        
    });
</script>