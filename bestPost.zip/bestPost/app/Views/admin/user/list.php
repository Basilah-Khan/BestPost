<?php echo view('admin/header'); ?>

    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded p-4">
            <h3> User List </h3>
        </div>
        <div class="bg-secondary rounded p-4 mt-3 mt-5">
            <table class="table">
                <thead>
                    <tr>
                        <th>Sr. No.</th>
                        <th>Date</th>
                        <th>Name</th>
                        <th>Username</th>
                        <th>Access</th>
                        <th>Action</th>
                    </tr>
                </thead>
                <tbody>
                    <?php 
                        foreach ($userList as $value){
                            echo '<tr>
                                    <td>'. $value['srno'] .'</td>
                                    <td>'. $value['date'] .'</td>
                                    <td>'. $value['fullname'] .'</td>
                                    <td>'. $value['username'] .'</td>
                                    <td>'. $value['access'] .'</td>
                                    <td>'. $value['action'] .'</td>
                                  </tr>';
                        }
                    ?>
                                
                </tbody>
            </table>
        </div>
    </div> 

<?php echo view('admin/footer'); ?>
<script type="text/javascript">
    function deleteUser(id) {
        cuteAlert({
            type: "question",
            title: "Are you sure to delete the user?",
            message: "",
            confirmText: "Yes",
            cancelText: "No"
        }).then((e)=>{
            console.log(e)
            if (e){
                $.ajax({
                    url: "<?php echo base_url() .'/api/ajaxDeleteUser'; ?>",
                    type: 'post',
                    data: { user_id: id },
                    dataType: 'json',
                    success: function (data) {
                        cuteToast({
                            title: data.title,
                            type: data.status,
                            message: data.message,
                            timer: 1500
                        });

                        if (data.status == 'success') {
                            setTimeout(function () {
                                window.location.reload();
                            },1600);
                        }
                        
                        $('.formbtn').prop('disabled', false);
                    },            
                    error: function (data) {
                        window.location.reload();
                        $('.formbtn').prop('disabled', false);
                    }
                });
            } 
        })
        return false;
    }
</script>