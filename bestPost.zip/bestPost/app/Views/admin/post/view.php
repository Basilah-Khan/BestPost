<?php echo view('admin/header'); ?>

    <div class="container-fluid pt-4 px-4">
        <?php if ($postData){ ?>
            <div class="bg-secondary rounded p-4">
                <h3><?php echo $postData['title']; ?> </h3>
            </div>
            <div class="bg-secondary rounded p-4 mt-3 mt-5" style="margin-bottom: 100px;">
                <div>
                    <img src="<?php echo base_url() . '/upload/image/'. $postData['image']; ?>" class='w=100'>
                </div>
                <div><?php echo $postData['text']; ?></div>
            </div>
        <?php }else{ ?>
            <div class="bg-secondary rounded p-4 mt-3 mt-5">
                <h3>Something went wrong </h3>
            </div>
        <?php } ?>
    </div> 

<?php echo view('admin/footer'); ?>