<?php echo view('admin/header'); ?>

    <div class="container-fluid pt-4 px-4">
        <div class="bg-secondary rounded p-4">
            <h3><?php if ($postData){ echo 'Add Post'; }else{ echo 'Edit Post'; } ?> </h3>
        </div>
        <div class="bg-secondary rounded p-4 mt-3 mt-5">
            <form id="postForm" method="POST" enctype="multipart/form-data">
                <div class="row">
                    <div class="col-md-6">
                        <div class="form-floating mb-3">
                            <input type="text" class="form-control" id="title" name="title" placeholder="Basilah Khan" value="<?php if ($postData){ echo $postData['title']; } ?>">
                            <label for="title">Title</label>
                        </div>
                    </div>
                    <div class="col-md-6">
                        <div class="form-group mb-3">
                            <label for="image">Image</label>
                            <?php if($postData){ ?>
                                <a href="<?php echo base_url().'/upload/image/' .$postData['image']; ?>">View Image</a>
                            <?php } ?>
                            <input type="file" class="form-control" id="image" name="image" placeholder="Basilah" value="" accept= "image/*">
                        </div>
                    </div>
                </div>
                <div class="row">
                    <div class="col-md-12">
                        <label for="text">Text</label>
                        <textarea id="text" name="text" placeholder="Text" class="form-control" maxlength="1000" style="height: 100px;"><?php if ($postData){ echo $postData['text']; } ?></textarea>
                    </div>
                    <input type="hidden" name="id" value="<?php if ($postData){ echo $postData['id']; } ?>">
                </div>
                <div class="row mt-2">
                    <div class="col-sm-3">
                    </div>
                    <div class="col-sm-3">
                        <button type="reset" class="btn btn-warning w-100">Rest</button>
                    </div>
                    <div class="col-sm-3">
                        <button type="submit" class="btn btn-primary w-100 formbtn">Save</button>
                    </div>
                    <div class="col-sm-3">
                    </div>
                </div>
            </form>
        </div>
    </div> 

<?php echo view('admin/footer'); ?>

<script type="text/javascript"> 
    <?php if ($postData){ ?>
        $("#postForm").validate({
            rules: {
              title: "required",
              text: "required"
            },
            messages: {
              title: "Please Enter Title. This field is required.",
              text: "Please Enter Text. This field is required."
            },
            errorPlacement: function (error, element) {
              error.insertBefore(element.parent());
            },
            submitHandler: function () {
                $('.formbtn').prop('disabled', true);

                var formData = new FormData();
                var img    = $('#image')[0].files[0];
                formData.append('image',img);

                var inputData = $("#postForm").serializeArray();
                for(var i in inputData){
                  formData.append(inputData[i].name,inputData[i].value);
                }

                $.ajax({
                    url: "<?php echo base_url() .'/api/ajaxEditPost'; ?>",
                    type: 'post',
                    data: formData,
                    dataType: 'json',
                    processData: false,
                    contentType: false,
                    success: function (data) {
                        cuteToast({
                            title: data.title,
                            type: data.status,
                            message: data.message,
                            timer: 1500
                        });

                        if (data.status == 'success') {
                            setTimeout(function () {
                                window.location.href = "<?php echo base_url() .'/post/list'; ?>";
                            },1600);
                        }
                        
                        $('.formbtn').prop('disabled', false);
                    },            
                    error: function (data) {
                        window.location.reload();
                        $('.formbtn').prop('disabled', false);
                    }
                });
                return false;
            }        
        });
    <?php }else{ ?>
        $("#postForm").validate({
            rules: {
              title: "required",
              image: "required",
              text: "required"
            },
            messages: {
              title: "Please Enter Title. This field is required.",
              image: "Please Upload Image. This field is required.",
              text: "Please Enter Text. This field is required."
            },
            errorPlacement: function (error, element) {
              error.insertBefore(element.parent());
            },
            submitHandler: function () {
                $('.formbtn').prop('disabled', true);

                var formData = new FormData();
                var img    = $('#image')[0].files[0];
                formData.append('image',img);

                var inputData = $("#postForm").serializeArray();
                for(var i in inputData){
                  formData.append(inputData[i].name,inputData[i].value);
                }

                $.ajax({
                    url: "<?php echo base_url().'/api/ajaxAddPost'; ?>",
                    type: 'post',
                    data: formData,
                    dataType: 'json',
                    processData: false,
                    contentType: false,
                    success: function (data) {
                        cuteToast({
                            title: data.title,
                            type: data.status,
                            message: data.message,
                            timer: 1500
                        });

                        if (data.status == 'success') {
                            setTimeout(function () {
                                window.location.href = "<?php echo base_url() .'/post/list'; ?>";
                            },1600);
                        }
                        
                        $('.formbtn').prop('disabled', false);
                    },            
                    error: function (data) {
                        window.location.reload();
                        $('.formbtn').prop('disabled', false);
                    }
                });
                return false;
            }        
        });
    <?php } ?>
</script>