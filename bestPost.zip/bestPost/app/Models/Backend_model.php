<?php
namespace App\Models;
use CodeIgniter\Model;

class Backend_model extends Model {

    protected $db;
 
    public function __construct() {
        parent::__construct();
        $this->db = \Config\Database::connect();
        $this->session = \Config\Services::session();
        $this->request = \Config\Services::request(); 
        $this->encrypter = \Config\Services::encrypter(); 
    } 

    // User
        public function userLogin($username,$password){ 
            $arrResponse = array();
            $query = $this->db->query("SELECT * FROM user WHERE username = '$username'");        
            if($query->getNumRows()>0){           
                $userDetails = $query->getResultArray()[0];

                if($this->encrypter->decrypt(hex2bin($userDetails['password'])) == $password) {
                    $sessionArray = array(
                        'user_id'   => $userDetails['id'],
                        'user_role' => $userDetails['role'],
                        'user_name' => $userDetails['fullname'],
                        'read'      => $userDetails['read_access'],
                        'update'    => $userDetails['update_access'],
                        'delete'    => $userDetails['delete_access'],
                        'admin'     => $userDetails['admin_access'],
                    );
                    $this->session->set('user_sesssion',$sessionArray);

                    $arrResponse['status'] = 'success';
                    $arrResponse['title'] = 'Success';
                    $arrResponse['message'] = 'Login Successful';
                }else{
                    $arrResponse['status'] = 'error';
                    $arrResponse['title'] = 'Error';
                    $arrResponse['message'] = 'Please enter currect password';
                }
            }else{
                $arrResponse['status'] = 'error';
                $arrResponse['title'] = 'Error';
                $arrResponse['message'] = 'Please enter correct username';
            }
            return $arrResponse;
        }

        public function getDashboardData($user_id = ''){ 
            $arrResponse = array();
            if ($user_id != '') {
                $arrResponse['users'] = 0;
                $query = $this->db->query("SELECT count(id) as posts FROM post WHERE user_id = $user_id");
                if($query->getNumRows()>0){           
                    $arrResponse['posts'] = $query->getResultArray()[0]['posts'];
                }else{
                    $arrResponse['posts'] = 0;
                }
            }else{
                $query = $this->db->query("SELECT count(id) as posts, (SELECT count(id) FROM user WHERE role != 'superadmin') as users FROM post");        
                if($query->getNumRows()>0){           
                    $data = $query->getResultArray()[0];

                    $arrResponse['users'] = $data['users'];
                    $arrResponse['posts'] = $data['posts'];
                }else{
                    $arrResponse['users'] = 0;
                    $arrResponse['posts'] = 0;
                }
            }
            return $arrResponse;
        }

        public function getUserData($user_id = ''){ 
            $arrResponse = array();
            if ($user_id != '') {
                $query = $this->db->query("SELECT * FROM user WHERE id = $user_id");
                if($query->getNumRows()>0){           
                    $data = $query->getResultArray()[0];
                    $data['password'] = $this->encrypter->decrypt(hex2bin($data['password']));
                    $arrResponse = $data;
                }
            }
            return $arrResponse;
        }

        public function getUserList(){ 
            $arrResponse = array();
            $query = $this->db->query("SELECT * FROM user WHERE role != 'superadmin' ");
            if($query->getNumRows()>0){           
                $data = $query->getResultArray();
                $arr = array(); $x=1;
                foreach ($data as $value) {
                    $access = $action = ''; $read = $update = 0;
                    if ($value['admin_access'] == '1') {
                        if ($value['read_access'] == '1') {
                            $read = 1; // setting read flag
                            $access = 'Read';
                        }
                        if ($value['update_access'] == '1') {
                            $update = 1;// setting update flag
                            if ($read == 1) {
                                $access .= ', Update';
                            }else{
                                $access = 'Update';
                            }
                        }
                        if ($value['delete_access'] == '1') {
                            if ($update == 1 || $read == 1) {
                                $access .= ', Delete';
                            }else{
                                $access = 'Delete';
                            }
                        }
                    }else{
                        $access = '-';
                    }

                    $action = "<a href='". base_url() .'/user/add_edit/'. $value['id'] ."' class='btn btn-primary mt-2'>Edit</a>";
                    $action .= "<button type='button' onclick='deleteUser(". $value['id'] .")' class='btn btn-danger ms-2 mt-2'>Delete</button>";

                    $arr = array(
                        'srno' => $x,
                        'date' => date('d M, y', strtotime($value['created_date'])),
                        'fullname' => ucfirst($value['fullname']),
                        'username' => $value['username'],
                        'access' => $access,
                        'action' => $action,
                    );
                    array_push($arrResponse, $arr);
                    $x++;
                }
            }else{
                $arrResponse = [];
            }
            return $arrResponse;
        }

        public function addUser($data){ 
            $arrResponse = array();
            $username = $data['username'];
            $query = $this->db->query("SELECT * FROM user WHERE username = '$username' ");
            if($query->getNumRows()>0){  
                $arrResponse['status']  = 'error';
                $arrResponse['title']   = 'Error';
                $arrResponse['message'] = 'User Exist';         
            }else{
                $admin_access = '0';
                if ($data['read_access'] == '1') {
                    $admin_access = '1';
                }else if ($data['update_access'] == '1') {
                    $admin_access = '1';
                }else if ($data['delete_access'] == '1') {
                    $admin_access = '1';
                }

                $arrayData = array(
                    'created_date'  => date('Y-m-d H:i:s'),
                    'role'          => 'admin',
                    'fullname'      => $data['fullname'],
                    'username'      => $data['username'],
                    'password'      => bin2hex($this->encrypter->encrypt($data['password'])),
                    'read_access'   => $data['read_access'],
                    'update_access' => $data['update_access'],
                    'delete_access' => $data['delete_access'],
                    'admin_access'  => $admin_access,
                );
                $this->db->table('user')->insert($arrayData);
                $affectedRows = $this->db->affectedRows();
                if ($affectedRows > 0) {
                    $arrResponse['status']  = 'success';
                    $arrResponse['title']   = 'Success';
                    $arrResponse['message'] = 'User added successfully';   
                }else{
                    $arrResponse['status']  = 'error';
                    $arrResponse['title']   = 'Error';
                    $arrResponse['message'] = 'Error occured while adding the user. Try again later.';   
                }
            }
            return $arrResponse;
        }

        public function editUser($data){ 
            $arrResponse = array();
            $id = $data['id'];
            $query = $this->db->query("SELECT * FROM user WHERE id = $id ");
            if($query->getNumRows()>0){  
                $admin_access = '0';
                if ($data['read_access'] == '1') {
                    $admin_access = '1';
                }else if ($data['update_access'] == '1') {
                    $admin_access = '1';
                }else if ($data['delete_access'] == '1') {
                    $admin_access = '1';
                }

                $arrayData = array(
                    'fullname'      => $data['fullname'],
                    'username'      => $data['username'],
                    'password'      => bin2hex($this->encrypter->encrypt($data['password'])),
                    'read_access'   => $data['read_access'],
                    'update_access' => $data['update_access'],
                    'delete_access' => $data['delete_access'],
                    'admin_access'  => $admin_access,
                );
                $builder = $this->db->table('user');
                $builder->where('id', $data['id']);
                $builder->where('role', 'admin');
                $builder->update($arrayData);
                $affectedRows = $this->db->affectedRows();
                if ($affectedRows > 0) {
                    $arrResponse['status']  = 'success';
                    $arrResponse['title']   = 'Success';
                    $arrResponse['message'] = 'User details edited successfully';   
                }else{
                    $arrResponse['status']  = 'error';
                    $arrResponse['title']   = 'Error';
                    $arrResponse['message'] = 'Error occured while editing the user details. Try again later.';  
                }         
            }else{
                $arrResponse['status']  = 'error';
                $arrResponse['title']   = 'Error';
                $arrResponse['message'] = 'User not found';
            }
            return $arrResponse;
        }

        public function deleteUser($user_id){ 
            $arrResponse = array();
            $query = $this->db->query("SELECT * FROM user WHERE id = $user_id ");
            if($query->getNumRows()>0){ 
                $builder = $this->db->table('user');
                $builder->where('id', $user_id);
                $builder->where('role', 'admin');
                $builder->delete();
                $affectedRows = $this->db->affectedRows();
                if ($affectedRows > 0) {
                    $arrResponse['status']  = 'success';
                    $arrResponse['title']   = 'Success';
                    $arrResponse['message'] = 'User details deleted successfully';   
                }else{
                    $arrResponse['status']  = 'error';
                    $arrResponse['title']   = 'Error';
                    $arrResponse['message'] = 'Error occured while deleting the user details. Try again later.'; 
                }         
            }else{
                $arrResponse['status']  = 'error';
                $arrResponse['title']   = 'Error';
                $arrResponse['message'] = 'User not found';
            }
            return $arrResponse;
        }
    // User


    // Post
        public function getPostData($post_id = ''){ 
            $arrResponse = array(); $append = '';
            if ($post_id != '') {            
                $session = $this->session->get('user_sesssion'); 
                if ($session['user_role'] == 'admin' && $session['update'] == '0') {
                    $append = " AND user_id = ".$session['user_id'] ." ";
                }

                $query = $this->db->query("SELECT * FROM post WHERE id = $post_id  $append ");
                if($query->getNumRows()>0){           
                    $arrResponse = $query->getResultArray()[0];
                }
            }
            return $arrResponse;
        }

        public function getPostList(){ 
            $arrResponse = array(); $append = '';          
            $session = $this->session->get('user_sesssion'); 
            if ($session['user_role'] == 'admin' && $session['admin'] == '0') {
                $append = " WHERE user_id = ".$session['user_id'] ." ";
            }

            $query = $this->db->query("SELECT * FROM post $append ");
            if($query->getNumRows()>0){           
                $data = $query->getResultArray();
                $arr = array(); $x=1;
                foreach ($data as $value) {
                    $access = $action = ''; $read = $update = 0;
                    if ($value['user_id'] != $session['user_id'] && $session['admin'] == '1') {
                        if ($session['read'] == '1') {
                            $action = '';
                        }
                        if ($session['update'] == '1') {
                            $action = "<a href='". base_url() .'/post/add_edit/'. $value['id'] ."' class='btn btn-primary mt-2'>Edit</a>";
                        }
                        if ($session['delete'] == '1') {
                            $action .= "<button type='button' onclick='deletePost(". $value['id'] .")' class='btn btn-danger ms-2 mt-2'>Delete</button>";
                        }

                        $image = "<img src='". base_url() ."/upload/image/". $value['image'] ."' style='width:100px;'>";
                        $title = "<a href='". base_url() .'/post/view/'. $value['id'] ."' >". ucfirst($value['title']) ."</a>";
                        $arr = array(
                            'srno'   => $x,
                            'date'   => date('d M, y', strtotime($value['created_date'])),
                            'title'  => $title,
                            'image'  => $image,
                            'text'   => $value['text'],
                            'action' => $action,
                        );
                        array_push($arrResponse, $arr);
                        $x++;
                    }else{

                        $action = "<a href='". base_url() .'/post/add_edit/'. $value['id'] ."' class='btn btn-primary mt-2'>Edit</a>";
                        $action .= "<button type='button' onclick='deletePost(". $value['id'] .")' class='btn btn-danger ms-2 mt-2'>Delete</button>";
                        $image = "<img src='". base_url() ."/upload/image/". $value['image'] ."' style='width:100px;'>";
                        $title = "<a href='". base_url() .'/post/view/'. $value['id'] ."' >". ucfirst($value['title']) ."</a>";

                        $arr = array(
                            'srno'   => $x,
                            'date'   => date('d M, y', strtotime($value['created_date'])),
                            'title'  => $title,
                            'image'  => $image,
                            'text'   => $value['text'],
                            'action' => $action,
                        );
                        array_push($arrResponse, $arr);
                        $x++;
                    }
                }
            }else{
                $arrResponse = [];
            }
            return $arrResponse;
        }

        public function addPost($data){ 
            $arrResponse = array();        
            $session = $this->session->get('user_sesssion'); 
            $title = $data['title'];
            $query = $this->db->query("SELECT * FROM post WHERE title = '$title' ");
            if($query->getNumRows()>0){  
                $arrResponse['status']  = 'error';
                $arrResponse['title']   = 'Error';
                $arrResponse['message'] = 'Post Exist';         
            }else{
                $generatedName = rand(1111,9999);
                $imgData = $this->request->getFile('image');
                if ($imgData) {
                    $filename = $imgData->getName();
                    $image = $generatedName.'.'.substr($filename, strpos($filename, ".") + 1);
                    $imgData->move(ROOTPATH . '/upload/image/', $image, true);
                }else{
                    $image = '';
                }

                $arrayData = array(
                    'created_date'  => date('Y-m-d H:i:s'),
                    'user_id'       => $session['user_id'],
                    'image'         => $image,
                    'text'          => $data['text'],
                    'title'         => $data['title'],
                );

                $this->db->table('post')->insert($arrayData);
                $affectedRows = $this->db->affectedRows();
                if ($affectedRows > 0) {
                    $arrResponse['status']  = 'success';
                    $arrResponse['title']   = 'Success';
                    $arrResponse['message'] = 'Post added successfully';   
                }else{
                    $arrResponse['status']  = 'error';
                    $arrResponse['title']   = 'Error';
                    $arrResponse['message'] = 'Error occured while adding the post. Try again later.';   
                }
            }
            return $arrResponse;
        }

        public function editPost($data){ 
            $arrResponse = array();
            $id = $data['id'];
            $query = $this->db->query("SELECT * FROM post WHERE id = $id ");
            if($query->getNumRows()>0){ 
                $arrayData = array(             
                    'text'  => $data['text'],
                    'title' => $data['title'],
                );

                $generatedName = rand(1111,9999);
                $imgData = $this->request->getFile('image');
                if ($imgData) {
                    $filename = $imgData->getName();
                    $image = $generatedName.'.'.substr($filename, strpos($filename, ".") + 1);
                    $imgData->move(ROOTPATH . '/upload/image/', $image, true);
                    $appendArray = array('image' => $image);
                    $arrayData   = $arrayData + $appendArray;
                }

                $builder = $this->db->table('post');
                $builder->where('id', $data['id']);
                $builder->update($arrayData);
                $affectedRows = $this->db->affectedRows();

                if ($affectedRows > 0) {
                    $arrResponse['status']  = 'success';
                    $arrResponse['title']   = 'Success';
                    $arrResponse['message'] = 'Post details edited successfully';   
                }else{
                    $arrResponse['status']  = 'error';
                    $arrResponse['title']   = 'Error';
                    $arrResponse['message'] = 'Error occured while editing the post details. Try again later.';  
                }         
            }else{
                $arrResponse['status']  = 'error';
                $arrResponse['title']   = 'Error';
                $arrResponse['message'] = 'Post not found';
            }
            return $arrResponse;
        }

        public function deletePost($post_id){ 
            $arrResponse = array();
            $session = $this->session->get('user_sesssion'); 

            $query = $this->db->query("SELECT * FROM post WHERE id = $post_id ");
            if($query->getNumRows()>0){ 
                $builder = $this->db->table('post');
                $builder->where('id', $post_id);
                $builder->delete();
                $affectedRows = $this->db->affectedRows();
                if ($affectedRows > 0) {
                    $arrResponse['status']  = 'success';
                    $arrResponse['title']   = 'Success';
                    $arrResponse['message'] = 'Post details deleted successfully';   
                }else{
                    $arrResponse['status']  = 'error';
                    $arrResponse['title']   = 'Error';
                    $arrResponse['message'] = 'Error occured while deleting the post details. Try again later.'; 
                }         
            }else{
                $arrResponse['status']  = 'error';
                $arrResponse['title']   = 'Error';
                $arrResponse['message'] = 'Post not found';
            }
            return $arrResponse;
        }
    // Post
}

