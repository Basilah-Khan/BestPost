<?php
namespace App\Controllers;

class Post extends BaseController{ 
    public function add_edit($post_id = ''){
        if ($this->session->has('user_sesssion')) {
            $data['session']   = $this->session->get('user_sesssion'); 

            if ($post_id != '') {
                $data['postData'] = $this->Backend->getPostData($post_id); 
            }else{
                $data['postData'] = [];
            }

            return view('admin/post/add_edit',$data);
        }else{
            return redirect()->to(base_url());
        }
    } 

    public function list(){
        if ($this->session->has('user_sesssion')) {
            $data['session']   = $this->session->get('user_sesssion'); 
            $data['postList'] = $this->Backend->getPostList();             

            return view('admin/post/list',$data);
        }else{
            return redirect()->to(base_url());
        }
    } 

    public function view($post_id = ''){
        if ($this->session->has('user_sesssion')) {
            $data['session']   = $this->session->get('user_sesssion'); 

            if ($post_id != '') {
                $data['postData'] = $this->Backend->getPostData($post_id); 
            }else{
                $data['postData'] = [];
            }

            return view('admin/post/view',$data);
        }else{
            return redirect()->to(base_url());
        }
    } 
}
