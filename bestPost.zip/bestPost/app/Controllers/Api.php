<?php
namespace App\Controllers;

class Api extends BaseController{ 

    // For User
        public function ajaxLogin(){
            header('Content-Type: application/json; charset=utf-8');
            $postData = $this->request->getPost();
            if($postData){
                $result = $this->Backend->userLogin($postData['username'],$postData['password']);          
              
                $arrayResponse['status']  = $result['status'];
                $arrayResponse['title']   = $result['title'];
                $arrayResponse['message'] = $result['message'];        
            }else{
                $arrayResponse['status']  = 'error';
                $arrayResponse['title']   = 'Error';
                $arrayResponse['message'] = 'Non-Authoritative Information';
            }
            echo json_encode($arrayResponse);
        }

        public function ajaxAddUser(){
            header('Content-Type: application/json; charset=utf-8');
            $postData = $this->request->getPost();
            if($postData){
                $result = $this->Backend->addUser($postData);          
              
                $arrayResponse['status']  = $result['status'];
                $arrayResponse['title']   = $result['title'];
                $arrayResponse['message'] = $result['message'];        
            }else{
                $arrayResponse['status']  = 'error';
                $arrayResponse['title']   = 'Error';
                $arrayResponse['message'] = 'Non-Authoritative Information';
            }
            echo json_encode($arrayResponse);
        }

        public function ajaxEditUser(){
            header('Content-Type: application/json; charset=utf-8');
            $postData = $this->request->getPost();
            if($postData){
                $result = $this->Backend->editUser($postData);          
              
                $arrayResponse['status']  = $result['status'];
                $arrayResponse['title']   = $result['title'];
                $arrayResponse['message'] = $result['message'];        
            }else{
                $arrayResponse['status']  = 'error';
                $arrayResponse['title']   = 'Error';
                $arrayResponse['message'] = 'Non-Authoritative Information';
            }
            echo json_encode($arrayResponse);
        }

        public function ajaxDeleteUser(){
            header('Content-Type: application/json; charset=utf-8');
            $postData = $this->request->getPost();
            if($postData){
                $result = $this->Backend->deleteUser($postData['user_id']);          
              
                $arrayResponse['status']  = $result['status'];
                $arrayResponse['title']   = $result['title'];
                $arrayResponse['message'] = $result['message'];        
            }else{
                $arrayResponse['status']  = 'error';
                $arrayResponse['title']   = 'Error';
                $arrayResponse['message'] = 'Non-Authoritative Information';
            }
            echo json_encode($arrayResponse);
        }
    // For User

    // For Post
        public function ajaxAddPost(){
            header('Content-Type: application/json; charset=utf-8');
            $postData = $this->request->getPost();
            if($postData){
                $result = $this->Backend->addPost($postData);          
              
                $arrayResponse['status']  = $result['status'];
                $arrayResponse['title']   = $result['title'];
                $arrayResponse['message'] = $result['message'];        
            }else{
                $arrayResponse['status']  = 'error';
                $arrayResponse['title']   = 'Error';
                $arrayResponse['message'] = 'Non-Authoritative Information';
            }
            echo json_encode($arrayResponse);
        }

        public function ajaxEditPost(){
            header('Content-Type: application/json; charset=utf-8');
            $postData = $this->request->getPost();
            if($postData){
                $result = $this->Backend->editPost($postData);          
              
                $arrayResponse['status']  = $result['status'];
                $arrayResponse['title']   = $result['title'];
                $arrayResponse['message'] = $result['message'];        
            }else{
                $arrayResponse['status']  = 'error';
                $arrayResponse['title']   = 'Error';
                $arrayResponse['message'] = 'Non-Authoritative Information';
            }
            echo json_encode($arrayResponse);
        }

        public function ajaxDeletePost(){
            header('Content-Type: application/json; charset=utf-8');
            $postData = $this->request->getPost();
            if($postData){
                $result = $this->Backend->deletePost($postData['post_id']);          
              
                $arrayResponse['status']  = $result['status'];
                $arrayResponse['title']   = $result['title'];
                $arrayResponse['message'] = $result['message'];        
            }else{
                $arrayResponse['status']  = 'error';
                $arrayResponse['title']   = 'Error';
                $arrayResponse['message'] = 'Non-Authoritative Information';
            }
            echo json_encode($arrayResponse);
        }
    // For Post
}
