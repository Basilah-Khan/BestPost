<?php
namespace App\Controllers;

class User extends BaseController{
    public function login(){
        if ($this->session->has('user_sesssion')) {
            return redirect()->to(base_url('/dashboard'));
        }
        return view('admin/login');
    } 
    
    public function logout(){
        if ($this->session->has('user_sesssion')) {
            $this->session->destroy();
            return redirect()->to(base_url());
        }
        return view('admin/dashboard');
    } 

    public function dashboard(){
        if ($this->session->has('user_sesssion')) {
            $data['session']   = $this->session->get('user_sesssion'); 
            if ($data['session']['user_role'] == 'admin') {
                $getDashboardData  = $this->Backend->getDashboardData($data['session']['user_id']); 
                $data['posts']     = $getDashboardData['posts'];
                $data['users']     = 0;
            }else{
                $getDashboardData  = $this->Backend->getDashboardData(); 
                $data['users']     = $getDashboardData['users'];
                $data['posts']     = $getDashboardData['posts'];
            }
            return view('admin/dashboard',$data);
        }else{
            return redirect()->to(base_url());
        }
    } 

    public function add_edit($user_id = ''){
        if ($this->session->has('user_sesssion')) {
            $data['session']   = $this->session->get('user_sesssion'); 

            if ($data['session']['user_role'] == 'admin') {
                return redirect()->to(base_url('/dashboard'));
            }

            if ($user_id != '') {
                $data['userData'] = $this->Backend->getUserData($user_id); 
            }else{
                $data['userData'] = [];
            }

            return view('admin/user/add_edit',$data);
        }else{
            return redirect()->to(base_url());
        }
    } 

    public function list(){
        if ($this->session->has('user_sesssion')) {
            $data['session']   = $this->session->get('user_sesssion'); 

            if ($data['session']['user_role'] == 'admin') {
                return redirect()->to(base_url('/dashboard'));
            }
            
            $data['userList'] = $this->Backend->getUserList(); 
            

            return view('admin/user/list',$data);
        }else{
            return redirect()->to(base_url());
        }
    } 
}
